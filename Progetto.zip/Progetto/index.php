
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Progetto Commerce</title>
    <!-- google-fonts -->
    <link href="//fonts.googleapis.com/css2?family=Source+Serif+Pro:wght@200;300;400;600;700;900&display=swap"
        rel="stylesheet">
    <link href="//fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <!-- //google-fonts -->
    <!-- Template CSS Style link -->
    <link rel="stylesheet" href="assets/css/style-starter.css">
</head>

<body>
    <div class="main-content">
        <!-- left header -->
        <div class="header-section">
            <!--header-->
            <header id="site-header" class="fixed-top">
                <div class="container p-lg-0">
                    <nav class="navbar navbar-expand-lg stroke p-lg-0">
                        <!-- <h1>
                            <a class="navbar-brand" href="index.html"><i class="fa fa-snowflake-o mr-2"
                                    aria-hidden="true"></i>Beauty Spot</a>
                        </h1>-->
                           
    <a class="navbar-brand" href="index.php">
        <img src="assets/images/logo-2.png" alt="Your logo" title="Your logo" style="height:59px; width:200px;" />
    </a> 
                        <button class="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse"
                            data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false"
                            aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon fa icon-expand fa-bars"></span>
                            <span class="navbar-toggler-icon fa icon-close fa-times"></span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="#home">Welcome to Progetto Commerce <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#about">Who We Are </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#services">Our Expertise</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#contact">Let's Talk Business</a>
                                </li>
                                
                            </ul>
                        </div>
                       
                        <div class="cont-details mt-5">
                            <div class="d-flex text-disp-content">
                                <i class="fa fa-envelope mr-2" aria-hidden="true"></i>
                                <div class="cont-right-dis">
                                    <label>Let's Connect</label>
                                    <p><a href="mailto:hello@progettocommerce.com">hello@progettocommerce.com</a></p>
                                </div>
                            </div>
                            <!-- <div class="d-flex text-disp-content mt-4 pt-xl-2">
                                <i class="fa fa-volume-control-phone mr-2" aria-hidden="true"></i>
                                <div class="cont-right-dis">
                                    <label>Call Us</label>
                                    <p><a href="tel:+1(21) 234 4567">+91 7972 355 616</a></p>
                                </div>
                            </div> -->
                        </div>
                        <div class="main-social-top mt-5 pt-xl-4 text-center">
                            <ul>
                                <li><a href="https://www.facebook.com/profile.php?id=61553920751481" class="facebook"><span class="fa fa-facebook"></span></a></li>
                                <!-- <li><a href="#twitter" class="twitter"><span class="fa fa-twitter"></span></a></li> -->
                                <li> <a href="https://www.instagram.com/progettocommerce/" class="instagram"><span class="fa fa-instagram"></span></a>
                                </li>
                                <li><a href="https://www.linkedin.com/company/105439085/admin/page-posts/published/" class="linkedin"><span class="fa fa-linkedin"></span></a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </header>
            <!--//header-->
        </div>
        <!-- //left header -->
        <!-- right content -->
        <div class="right-content-section">
            <!-- banner section -->
            <section class="w3l-main-slider" id="home">
                <div class="banner-content">
                    <div id="demo-1"
                        data-zs-src='["assets/images/banner1.jpg"]'
                        data-zs-overlay="dots">
                        <div class="demo-inner-content">
                            <div class="container">
                                <div class="banner-info">
                                    <h3>Accelerate Your <span style="color:#0D41E1;">Amazon Growth</span></h3>
                                    <p class="mt-1">Maximize your sales, boost your brand visibility, and unlock new opportunities on the world's largest marketplace.</p>
                                    <a class="btn btn-style mt-4" href="#appointment">Explore Services</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- //banner section -->

            <!-- about section -->
            <section class="w3l-text-6 py-5" id="about">
                <div class="text-6-mian py-md-4 py-3">
                    <div class="container">
                        <div class="row top-cont-grid align-items-center">
                            <div class="col-lg-6 left-img pr-lg-4">
                                <img src="assets/images/about.jpg" alt="" class="img-responsive img-fluid" />
                            </div>
                            <div class="col-lg-6 text-6-info mt-lg-0 mt-4">
                                <h3 class="title-style">Who we <span style="color:#0D41E1;">are</span></h3>
                                <p class="sub-title">We Don’t Just Support — We Scale</p>
                                <p class="mt-4"><b>Progetto Commerce</b> is a results-driven e-commerce agency that helps brands grow and thrive on the Amazon marketplace. We offer complete end-to-end solutions — from product listings, A+ content, and creative design to running targeted Amazon ads that drive real sales. Our goal is to boost your brand’s visibility, increase conversions, and help you scale profitably in today’s competitive digital landscape.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- //about section -->

            <!-- providing services section -->
            <section class="w3l-content-11-main" id="services">
                <div class="content-design-11 py-5">
                    <div class="container py-md-5 py-4">
                        <h3 class="title-style">Our <span style="color:#0D41E1;">Expertise</span></h3>
                        <p class="sub-title">
                            Strategic Services to Scale Your Amazon Success
                        </p>
                        <div class="content-sec-11 mt-5">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="services-single d-flex p-sm-5 p-4">
                                        <div class="service-icon mr-sm-4 mr-3">
                                            <i class="fa fa-paint-brush" aria-hidden="true"></i>
                                        </div>
                                        <div class="services-content">
                                            <h5><a href="services.html">Amazon Listing & Optimization</a></h5>
                                            <p>High-quality product listing creation and keyword optimization to improve search ranking and conversion rates.</p>
                                            <!-- <a href="#services"
                                                class="btn read-button d-flex align-items-center mt-4 p-0">Read
                                                More<i class="fa fa-angle-double-right ml-1" aria-hidden="true"></i></a> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="services-single d-flex p-sm-5 p-4">
                                        <div class="service-icon mr-sm-4 mr-3">
                                            <i class="fa fa-paint-brush" aria-hidden="true"></i>
                                        </div>
                                        <div class="services-content">
                                            <h5><a href="services.html">A+ Content & Brand Store Design</a></h5>
                                            <p>We design A+ Content and Brand Stores that visually communicate your brand’s story.
Our designs build trust, engage shoppers, and drive more conversions.</p>
                                            <!-- <a href="#services"
                                                class="btn read-button d-flex align-items-center mt-4 p-0">Read
                                                More<i class="fa fa-angle-double-right ml-1" aria-hidden="true"></i></a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="services-single d-flex p-sm-5 p-4 mb-lg-0">
                                        <div class="service-icon mr-sm-4 mr-3">
                                            <i class="fa fa-eye" aria-hidden="true"></i>
                                        </div>
                                        <div class="services-content">
                                            <h5><a href="services.html">Amazon Advertising (PPC Management)</a></h5>
                                            <p>Targeted ad campaigns to drive traffic, boost visibility, and maximize return on ad spend.</p>
                                            <!-- <a href="#services"
                                                class="btn read-button d-flex align-items-center mt-4 p-0">Read
                                                More<i class="fa fa-angle-double-right ml-1" aria-hidden="true"></i></a> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="services-single d-flex p-sm-5 p-4 mb-0">
                                        <div class="service-icon mr-sm-4 mr-3">
                                            <i class="fa fa-leaf" aria-hidden="true"></i>
                                        </div>
                                        <div class="services-content">
                                            <h5><a href="services.html">Creative & Infographic Design</a></h5>
                                            <p>Eye-catching product infographics, packaging designs, and marketing creatives tailored to your brand.</p>
                                            <!-- <a href="#services"
                                                class="btn read-button d-flex align-items-center mt-4 p-0">Read
                                                More<i class="fa fa-angle-double-right ml-1" aria-hidden="true"></i></a> -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- //providing services section -->

            <!-- about block 3 -->
            <section class="about-block-3 py-5">
                <div class="grids-w3ovt py-md-5 py-4">
                    <div class="container">
                        <h3 class="title-style">Why Choose <span style="color:#0D41E1;">Progetto Commerce?</span></h3>
                        <p class="sub-title">Expertise, creativity, and strategy — all in one place.</p>
                        <div class="row mt-5">
                            <div class="col-md-4 mb-md-0 mb-5">
                                <div class="bg-color-block-2">
                                    <!-- <h6 class="top-grid-text text-uppercase"><label>01.</label>Our Values</h6> -->
                                    <h3 class="grid-one-text mb-3" style="color:#07C8F9;">Amazon Expertise</h3>
                                    <p>Our team knows the ins and outs of Amazon from Seller Central to ad campaigns delivering solutions that align with platform best practices.</p>
                                </div>
                            </div>
                            <div class="col-md-4 mb-md-0 mb-5">
                                <div class="bg-color-block-2">
                                    <!-- <h6 class="top-grid-text text-uppercase"><label>02.</label>Who We Are</h6> -->
                                    <h3 class="grid-one-text mb-3" style="color:#07C8F9;">End-to-End Services</h3>
                                    <p>From product listings and A+ content to advertising and storefront design, we provide complete support to help your brand grow faster.</p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="bg-color-block-2">
                                    <!-- <h6 class="top-grid-text text-uppercase"><label>03.</label>What We Do</h6> -->
                                    <h3 class="grid-one-text mb-3" style="color:#07C8F9;"> Data-Driven Strategies</h3>
                                    <p>We use analytics, keyword research, and performance data to create strategies that improve visibility, conversions, and profitability.</p>
                                </div>
                            </div>

                        </div>
                        <div class="row mt-5">
                            <div class="col-md-4 mb-md-0 mb-5">
                                <div class="bg-color-block-2">
                                    <!-- <h6 class="top-grid-text text-uppercase"><label>01.</label>Our Values</h6> -->
                                    <h3 class="grid-one-text mb-3" style="color:#07C8F9;"> Creative Excellence</h3>
                                    <p>Our in-house design team crafts visually compelling content that builds trust, communicates value, and drives buyer action.</p>
                                </div>
                            </div>
                            <div class="col-md-4 mb-md-0 mb-5">
                                <div class="bg-color-block-2">
                                    <!-- <h6 class="top-grid-text text-uppercase"><label>02.</label>Who We Are</h6> -->
                                    <h3 class="grid-one-text mb-3" style="color:#07C8F9;">Client-Centric Approach</h3>
                                    <p>We treat your brand like our own, offering personalized support, quick communication, and results you can measure.</p>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </section>
            <!-- //about block 3 -->

            <!-- blog section -->
            <section class="w3l-content-11-main" style="background-image: url('assets/images/banner2.jpg'); background-repeat: no-repeat; background-attachment: fixed; background-size: 100% 100%;">
            <div class="w3l-grids-block-5">
                <div class="container py-md-5 py-4" style="text-align: center;">
                    <h3 class="title-style" style="border:0px !important; color: white;">Unlock Your Amazon Growth Potential</h3>
                    <p class="mt-2" style="color:white;">Ready to take your brand to the next level? </p>
<p style="color:white;">Our tailored services are built to boost visibility, sales, and long-term success on Amazon.</p>
                    <div class="mt-md-5 mt-4 text-center">
                        <a class="btn btn-style mt-2" href="mailto:hello@progettocommerce.com">Let’s Grow Together</a>
                    </div>
                </div>
            </div>
        </section>
            <!-- //blog section -->
            <!-- contact page -->
            <section class="w3l-contacts-12 py-5" id="contact">
                <div class="container py-lg-5 py-md-4 py-3">
                    <h3 class="title-style">Let's Talk <span style="color:#0D41E1;">Business</span></h3>
                    <!-- <p>Contact with us now</p> -->
                    <div class="row contact-grids mt-5">
                        <div class="col-lg-12 contacts12-main">
                            <form action="" method="post" class="signin-form">
                                <div class="row input-grids">
                                    <div class="col-sm-6">
                                        <input type="text" name="proName" placeholder="Full name"
                                            class="contact-input" required="" />
                                    </div>
                                    <div class="col-sm-6 mt-sm-0 mt-4">
                                        <input type="email" name="promail" placeholder="Your email"
                                            class="contact-input" required="" />
                                    </div>
                                </div>
                                <div class="row input-grids my-4">
                                    <div class="col-sm-6">
                                        <input type="text" name="proCompany" placeholder="Company Name"
                                            class="contact-input"  required=""/>
                                    </div>
                                    <div class="col-sm-6 mt-sm-0 mt-4">
                                        <input type="text" name="proNumber" placeholder="Phone number"
                                            class="contact-input" required="" />
                                    </div>
                                </div>
                                <textarea name="proMsg" placeholder="Type your message here" required=""></textarea>
                                <button class="btn btn-style mt-5" type="submit">Send Message</button>
                            </form>
                        </div>

                        <?php
    $link = mysqli_connect("localhost", "root", "", "progetto_db");

    if(isset($_POST['proName']) && !empty($_POST['proName']))
    {
        $name = ($_POST["proName"]);
        $email = ($_POST["promail"]);
        $companyName = ($_POST["proCompany"]);
        $phoneNum = ($_POST["proNumber"]);
        $msg = ($_POST["proMsg"]);

        $sql = "INSERT INTO contact(id, name, email, company_Name, phone_Num, msg) VALUES(NULL, '$name', '$email', '$companyName', '$phoneNum', '$msg')";
        $result = mysqli_query($link, $sql) or die(mysqli_error($link));
        
        if($result)
        { ?>
            <script>
                {
                    alert("Thank you for reaching out! Your message has been successfully submitted. Our team will get back to you shortly");
                }
            </script>
<?php   }
        else
        { ?>
            <script>
                {
                    alert("Error!");
                }
            </script>
<?php   }
    }
?>
                        <!-- <div class="col-lg-5 contact-right mt-lg-0 mt-5">
                            <div class="details-style d-flex">
                                <span class="fa fa-map-marker"></span>
                                <div class="location-info">
                                    <span>Location</span>
                                    <p> Dolor sit, #PTH, 55030, 8500 Lorem Street</p>
                                    <p>sed at ipsum, #2114 agro towers</p>
                                    <p>United kingdom, UK.</p>
                                </div>
                            </div>
                            <div class="details-style d-flex">
                                <span class="fa fa-envelope-open"></span>
                                <div class="email-info">
                                    <span>Have any Questions?</span>
                                    <a href="mailto:hello@example.com">hello@progettocommerce.com</a>
                                </div>
                            </div>
                            <div class="details-style d-flex">
                                <span class="fa fa-phone"></span>
                                <div class="email-info">
                                    <span>Phone Number</span>
                                    <a href="tel:(123) 456-78-90"> (123) 456-78-90</a>
                                </div>
                            </div>
                        </div> -->
                    </div>
                    <!-- <div class="map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d423286.27404345275!2d-118.69191921441556!3d34.02016130939095!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80c2c75ddc27da13%3A0xe22fdf6f254608f4!2sLos+Angeles%2C+CA%2C+USA!5e0!3m2!1sen!2sin!4v1522474296007"
                            allowfullscreen=""></iframe>
                    </div> -->
                </div>
            </section>
            <!-- //contact page -->

            <!-- footer -->
                <div class="footer-dot">
                    <!-- copyright -->
                    <div class="cpy-right text-center py-4 mt-4">
                        <p class="text-white" style="font-size: 13px; important">© 2025 Progetto Commerce All rights reserved | Design by
                            <a href="https://progettocommerce.com" class="text-white">Progetto Commerce</a>
                        </p>
                    </div>
                    <!-- //copyright -->
                </div>
            <!-- //footer -->
        </div>
        <!-- //right content -->
    </div>

    <!-- Js scripts -->
    <!-- move top -->
    <button onclick="topFunction()" id="movetop" title="Go to top">
        <span class="fa fa-level-up" aria-hidden="true"></span>
    </button>
    <script>
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function () {
            scrollFunction()
        };

        function scrollFunction() {
            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                document.getElementById("movetop").style.display = "block";
            } else {
                document.getElementById("movetop").style.display = "none";
            }
        }

        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        }
    </script>
    <!-- //move top -->

    <!-- common jquery plugin -->
    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <!-- //common jquery plugin -->

    <!-- theme switch js (light and dark)-->
    <script src="assets/js/theme-change.js"></script>
    <script>
        function autoType(elementClass, typingSpeed) {
            var thhis = $(elementClass);
            thhis.css({
                "position": "relative",
                "display": "inline-block"
            });
            thhis.prepend('<div class="cursor" style="right: initial; left:0;"></div>');
            thhis = thhis.find(".text-js");
            var text = thhis.text().trim().split('');
            var amntOfChars = text.length;
            var newString = "";
            thhis.text("|");
            setTimeout(function () {
                thhis.css("opacity", 1);
                thhis.prev().removeAttr("style");
                thhis.text("");
                for (var i = 0; i < amntOfChars; i++) {
                    (function (i, char) {
                        setTimeout(function () {
                            newString += char;
                            thhis.text(newString);
                        }, i * typingSpeed);
                    })(i + 1, text[i]);
                }
            }, 1500);
        }

        $(document).ready(function () {
            // Now to start autoTyping just call the autoType function with the 
            // class of outer div
            // The second paramter is the speed between each letter is typed.   
            autoType(".type-js", 200);
        });
    </script>
    <!-- //theme switch js (light and dark)-->

    <!-- banner slider -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/modernizr-2.6.2.min.js"></script>
    <script src="assets/js/jquery.zoomslider.min.js"></script>
    <!-- //banner slider -->

    <!-- brands owl -->
    <script src="assets/js/owl-carousel.js"></script>
    <script>
        $(document).ready(function () {
            $('.owl-carousel').owlCarousel({
                loop: true,
                margin: 0,
                responsiveClass: true,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplaySpeed: 1000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1,
                        nav: true
                    },
                    480: {
                        items: 2,
                        nav: true,
                        margin: 20
                    },
                    667: {
                        items: 2,
                        nav: true,
                        margin: 20
                    },
                    1000: {
                        items: 3,
                        nav: true,
                        margin: 20
                    }
                }
            })
        })
    </script>
    <!-- //brands owl -->

    <!-- MENU-JS -->
    <script>
        $(window).on("scroll", function () {
            var scroll = $(window).scrollTop();

            if (scroll >= 80) {
                $("#site-header").addClass("nav-fixed");
            } else {
                $("#site-header").removeClass("nav-fixed");
            }
        });

        //Main navigation Active Class Add Remove
        $(".navbar-toggler").on("click", function () {
            $("header").toggleClass("active");
        });
        $(document).on("ready", function () {
            if ($(window).width() > 991) {
                $("header").removeClass("active");
            }
            $(window).on("resize", function () {
                if ($(window).width() > 991) {
                    $("header").removeClass("active");
                }
            });
        });
    </script>
    <!-- //MENU-JS -->

    <!-- disable body scroll which navbar is in active -->
    <script>
        $(function () {
            $('.navbar-toggler').click(function () {
                $('body').toggleClass('noscroll');
            })
        });
    </script>
    <!-- //disable body scroll which navbar is in active -->
    
    <!--bootstrap-->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- //bootstrap-->
    <!-- //Js scripts -->
</body>

</html>