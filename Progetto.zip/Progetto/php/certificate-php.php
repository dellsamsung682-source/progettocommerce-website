<?php
	include("database.php");
		
		
	if(isset($_POST['regNo']) && !empty($_POST['regNo']))
	{
		$regNo = ($_POST["regNo"]);
		$sql = "select * from certificate where regno = '$regNo'";
		$result = mysqli_query($link,$sql);
		$row = mysqli_fetch_array($result);
		if($row)
		{	$cid = $row['id'];
			header("Location: image2.php?id=$cid");
		}
		else
		{ ?>
			<script>
				{
					alert("Gen. Reg. No. is incorrect!");
				}
			</script>
			
	<?php	}
		
	}
?>