<?php
	include("database.php");
		

	if(isset($_POST['name']) && !empty($_POST['name']))
	{
		$name = ($_POST["name"]);
		$email = ($_POST["email"]);
		$phoneNum = ($_POST["phoneNum"]);
		$msg = ($_POST["msg"]);

		$sql = "INSERT INTO contact(id, name, email, phone, msg) VALUES(NULL, '$name', '$email', '$phoneNum', '$msg')";
		$result = mysqli_query($link, $sql) or die(mysqli_error($link));
		
		if($result)
		{ ?>
			<script>
				{
					alert("Submit successfully!");
				}
			</script>
<?php	}
		else
		{ ?>
			<script>
				{
					alert("Error!");
				}
			</script>
<?php	}
	}
?>